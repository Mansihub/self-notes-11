use company;
create table trigger_test(
message varchar(100)
);
DELIMITER $$
CREATE
    TRIGGER my_trigger before insert
    on employee
    for each row begin
       insert into trigger_test values('added new employee');
	end$$
DELIMITER ;
INSERT INTO employee VALUES(1000, 'Jaa', 'Levinsono', '1966-08-18', 'M', 110000, 100, 1);

select * from trigger_test;
DELIMITER $$
CREATE
    TRIGGER my_trigger1 before insert
    on employee
    for each row begin
       insert into trigger_test values('NEW.first_name');
	end$$
DELIMITER ;
INSERT INTO employee VALUES(1070, 'Jama', 'Levinsyono', '1969-08-18', 'F', 110000, 100, 1);
select * from trigger_test;

delimiter $$
CREATE
    TRIGGER my_trigger3 before insert
    on employee
    for each row begin
        IF NEW.sex='F' then
            insert into trigger_test values('added female employee');
	    elseif NEW.sex='M' then
            insert into trigger_test values('added male employee');
	    ELSE
            insert into trigger_test values('added other employee'); 
	    end if;
	end$$
DELIMITER ;
INSERT INTO employee VALUES(1900, 'KYma', 'LeviYHono', '1969-09-09', 'F', 110000, 100, 1);
select * from trigger_test;
