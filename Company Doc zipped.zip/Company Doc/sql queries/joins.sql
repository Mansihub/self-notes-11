use company;
insert into branch values(4,'jhotwara',NULL,NULL);
SELECT * FROM branch;
--showing branch name with their managers name
select employee.emp_id,employee.first_name as managerName,branch.branch_name
from employee
join branch
on employee.emp_id=branch.mgr_id;
--left join:will show names of all employees whether they are manager or not
select employee.emp_id,employee.first_name as managerName,branch.branch_name
from employee
left join branch
on employee.emp_id=branch.mgr_id;

--right join->will show all branches whether they have manager or not
select employee.emp_id,employee.first_name as managerName,branch.branch_name
from employee
right join branch
on employee.emp_id=branch.mgr_id;
