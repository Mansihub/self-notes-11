use company;
select count(emp_id) 
from employee;
--number of supervisors
select count(super_id) 
from employee;
select count(emp_id) 
from employee where sex='F' And birth_day>'1971-01-01';

select avg(salary) from employee where sex='M';
select sum(salary) from employee;
select count(sex) ,sex from employee group by sex;

select sum(total_sales) ,emp_id
from works_with
group by emp_id;

select sum(total_sales) ,client_id
from works_with
group by client_id;
--wildcard
select * 
from client
where client_name like '%LLC'