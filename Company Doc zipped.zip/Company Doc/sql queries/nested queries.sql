use company;
select employee.first_name,employee.last_name
from employee
where emp_id in
(select works_with.emp_id 
from works_with
where works_with.total_sales>30000);

select client.client_name
from client
where client.branch_id = (
select employee.branch_id 
from employee
where employee.first_name='Michael' and employee.last_name='Scott');