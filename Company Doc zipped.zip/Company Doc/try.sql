create database test;
use test;
create table student3(
student_id int auto_increment ,
name varchar(20) not null,
major varchar(10) unique,
newcol varchar(30) default 'undecided',
primary key(student_id)
);
insert into student3(name,major) values('jay','psycho');
insert into student3(name,major) values('jaya','literature');
describe student3;
select * from student3;
select name from student3;
update student3 set major='bio' where major='literature';
update student3 set major='evs' where student_id=1;
SET SQL_SAFE_UPDATES = 0;
update student3 set name='zavis' where student_id=2;
select * from student3;
select name from student3 order by name desc;

delete from student3 where student_id=1 ;
insert into student2(student_id,name) values(6,'c');
insert into student2 values(7,'a','math');
describe student2;
alter table student add gpa int;
alter table student drop gpa;
drop table student;
insert into student1 values(7,'a','math');
insert into student1 values(5,'b','math');
insert into student(student_id,name) values(6,'c');
select * from student;